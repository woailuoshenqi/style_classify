# -*- coding: utf-8 -*-

import os 
classes = ['ethnic_style','ea_style','punk','jp_style','maid_style','ladylike','leisure']
data_path = ''
with open('train.txt','w') as f:
    paths = os.listdir(data_path)
    for path in paths:
        for image in os.listdir(os.path.join(data_path,path)):
            if image.endswith("jpg"):
                f.write(image + ";" + str(classes.index(path)) + "\n")
            	
